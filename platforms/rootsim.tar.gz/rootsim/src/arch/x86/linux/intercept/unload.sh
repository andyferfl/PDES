sudo rmmod intercept
